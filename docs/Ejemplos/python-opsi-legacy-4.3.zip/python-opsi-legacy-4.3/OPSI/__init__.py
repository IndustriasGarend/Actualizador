# -*- coding: utf-8 -*-

# Copyright (c) uib GmbH <info@uib.de>
# License: AGPL-3.0
"""
opsi python library.

This module is part of the desktop management solution opsi
(open pc server integration) http://www.opsi.org
"""

__version__ = "4.3.0.28"
