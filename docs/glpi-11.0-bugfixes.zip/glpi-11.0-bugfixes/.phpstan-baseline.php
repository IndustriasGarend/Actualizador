<?php declare(strict_types = 1);

$ignoreErrors = [];

return ['parameters' => ['ignoreErrors' => $ignoreErrors]];
