# GLPI docker devcontainers

The docker devcontainers are meant to be used by VSCode or in a Github Codespaces environment.

See the main `README.md` file in the `../.docker` folder.
