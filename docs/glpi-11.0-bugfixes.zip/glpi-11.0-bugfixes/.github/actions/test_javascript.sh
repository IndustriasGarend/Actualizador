#!/bin/bash
set -e -u -x -o pipefail

npm run-script test
