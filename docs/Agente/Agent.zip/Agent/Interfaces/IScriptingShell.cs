﻿namespace Remotely.Agent.Interfaces;
public interface IScriptingShell
{
    bool IsDisposed { get; }
}
